<?php
$con = mysqli_connect("localhost","root","","demo")or die(mysqli_error($con));
?>