<?php
include "Connection.php";
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
</head>

<body>

    <pre></pre>
    <h2 style="text-align: center;">How to Import Data from Excel (CSV, xls, xlsx) File to Mysqli in PHP using PhpSpreadsheet</h2>
    <pre>
    </pre>
    <?php
    if (isset($_SESSION['status'])) {
        echo "<h5 style='margin-left: 25%;'>" . $_SESSION['status'] . "</h5>";
        unset($_SESSION['status']);
    }
    ?>
    <form action="code.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <input type="file" name="import_file" style="width: 50%;margin-left: 25%;" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
        </div>

        <pre></pre>
        <button type="submit" name="import_file_btn" style="margin-left: 25%;" class="btn btn-primary">Submit</button>
    </form>

    <div class="card" style="border: none;">

        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h2>Users data</h2>
                </div>
                <div class="col-md-6">
                    <form action="code.php" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <select name="export_file_type" required class="form-control">
                                    <option value="">Select any one</option>
                                    <option value="xlsx">xlsx</option>
                                    <option value="xls">xls</option>
                                    <option value="csv">csv</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <button type="submit" name="export_btn" class="btn btn-primary">Export</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <table class="table">
                <thead class="thead-dark">
                    <tr class="table-dark">
                        <th scope="col">#</th>
                        <th scope="col">name</th>
                        <th scope="col">email</th>
                        <th scope="col">mobile</th>
                        <th scope="col">address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = mysqli_query($con, "select * from users");
                    $cnt = 1;
                    while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                        <tr>
                            <td><?php echo $cnt;
                                $cnt++; ?></td>
                            <td><?php echo $row["name"] ?></td>
                            <td><?php echo $row["email"] ?></td>
                            <td><?php echo $row["mobile"] ?></td>
                            <td><?php echo $row["address"] ?></td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

</html>