<?php
session_start();
include "Connection.php";
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Writer\Xls;
use PhpOffice\PhpSpreadsheet\Writer\Csv;



if (isset($_POST['export_btn'])) {

    $ext = $_POST['export_file_type'];
    // $fileName = "Users-sheet-" . time();
    $fileName = "Book1";

    $query = mysqli_query($con, "select * from users");

    if (mysqli_num_rows($query) > 0) {


        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $sheet->setCellValue('A1', 'id');
        $sheet->setCellValue('B1', 'name');
        $sheet->setCellValue('C1', 'email');
        $sheet->setCellValue('D1', 'mobile');
        $sheet->setCellValue('E1', 'address');

        $rowCount = 2;
        foreach ($query as $data) {
            $sheet->setCellValue('A' . $rowCount, $data['id']);
            $sheet->setCellValue('B' . $rowCount, $data['name']);
            $sheet->setCellValue('C' . $rowCount, $data['email']);
            $sheet->setCellValue('D' . $rowCount, $data['mobile']);
            $sheet->setCellValue('E' . $rowCount, $data['address']);
            $rowCount++;
        }

        if ($ext == 'xlsx') {
            $writer = new Xlsx($spreadsheet);
            $final_fileName = $fileName . '.xlsx';
        } else if ($ext == 'xls') {
            $writer = new Xls($spreadsheet);
            $final_fileName = $fileName . '.xls';
        } else if ($ext == 'csv') {
            $writer = new Csv($spreadsheet);
            $final_fileName = $fileName . '.csv';
        }
        // $writer->save($final_fileName);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attactment; filename="' . urlencode($final_fileName) . '"');
        $writer->save('php://output');
    } else {
        $_SESSION['status'] = "No Record found to export";
        header("Location: index.php");
        exit(0);
    }
}









if (isset($_POST['import_file_btn'])) {

    $allowed_ext = ['xls', 'csv', 'xlsx'];
    $fileName = $_FILES['import_file']['name'];
    $checking = explode(".", $fileName);
    $file_ext = end($checking);

    if (in_array($file_ext, $allowed_ext)) {
        $targetpath = $_FILES['import_file']['name'];
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($targetpath);
        $data = $spreadsheet->getActiveSheet()->toArray();

        $countno = "0";
        foreach ($data as $row) {

            if ($countno > 0) {
                $id = $row[0];
                $name = $row[1];
                $email = $row[2];
                $mobile = $row[3];
                $address = $row[4];

                $checkUser = mysqli_query($con, "select * from users where id='$id'");

                if (mysqli_num_rows($checkUser) > 0) {
                    // Already Exists means please update
                    $result = mysqli_query($con, "UPDATE `users` SET `name`='$name',`email`='$email',`mobile`='$mobile',`address`='$address' WHERE id='$id'");
                    $msg = 1;
                } else {
                    // New record hao toh insert
                    $in_resilt = mysqli_query($con, "INSERT INTO `users`(`name`, `email`, `mobile`, `address`) VALUES ('$name','$email','$mobile','$address')");
                    $msg = 1;
                }
            } else {
                $countno = "1";
            }

            if (isset($msg)) {
                $_SESSION['status'] = "File Imported Successfully";
                header("Location: index.php");
            } else {
                $_SESSION['status'] = "File Imported Failed";
                header("Location: index.php");
            }
        }
    } else {
        $_SESSION["status"] = "Invalid File";
        header("Location: index.php");
        exit(0);
    }
}
